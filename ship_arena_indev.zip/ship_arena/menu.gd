extends Control

func _on_play_pressed() -> void:
	get_tree().change_scene_to_file("res://main_game.tscn")

func _on_shipyard_pressed() -> void:
	pass # Replace with function body.

func _on_options_pressed() -> void:
	get_tree().change_scene_to_file("res://options_menu.tscn")

func _on_donate_pressed() -> void:
	get_tree().change_scene_to_file("res://donate.tscn")

func _on_quit_pressed() -> void:
	get_tree().quit()
