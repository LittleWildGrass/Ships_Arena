extends CharacterBody2D
class_name Player_Ship

var acceleration:float = 120.0
var max_speed:float = 300.0
var friction:float = 0.01
var input:Vector2 = Vector2.ZERO

func _physics_process(delta: float) -> void:
	
	$allien_ship.rotate(0.02)
	
	if Input.is_action_pressed("move_up"):
		input.y -= 1
	elif Input.is_action_pressed("move_down"):
		input.y += 1
	else:
		input.y = 0
	
	if Input.is_action_pressed("move_right"):
		input.x += 1
	elif Input.is_action_pressed("move_left"):
		input.x -= 1
	else:
		input.x = 0

	input = input.normalized()
	
	velocity += acceleration * input * delta
	
	if velocity != Vector2.ZERO:
		velocity = lerp(velocity,Vector2.ZERO,friction)
	
	velocity.limit_length(max_speed)
	
	move_and_slide()
	
